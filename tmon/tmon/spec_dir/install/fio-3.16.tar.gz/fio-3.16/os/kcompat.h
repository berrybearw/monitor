#ifndef _KCOMPAT_H_
#define _KCOMPAT_H_

#include <stdint.h>

#define u64 uint64_t
#define u32 uint32_t

#endif
