fio - Flexible I/O tester rev. |version|
========================================


.. include:: ../README


.. include:: ../HOWTO



Examples
========

.. include:: fio_examples.rst



TODO
====


GFIO TODO
---------

.. include:: ../GFIO-TODO


Server TODO
-----------

.. include:: ../SERVER-TODO


Steady State TODO
-----------------

.. include:: ../STEADYSTATE-TODO



Moral License
=============

.. include:: ../MORAL-LICENSE


License
=======

.. literalinclude:: ../COPYING
